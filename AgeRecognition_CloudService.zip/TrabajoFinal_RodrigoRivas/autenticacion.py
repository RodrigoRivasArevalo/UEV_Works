import base64 
from distutils.debug import DEBUG
from http.server import HTTPServer, BaseHTTPRequestHandler
import ssl
import json
import requests
import hashlib
from clarifai_grpc.channel.clarifai_channel import ClarifaiChannel
from clarifai_grpc.grpc.api import resources_pb2, service_pb2, service_pb2_grpc
from clarifai_grpc.grpc.api.status import status_code_pb2
import pymongo
from pymongo.mongo_client import MongoClient
from pymongo.server_api import ServerApi
from urllib.parse import quote_plus



username= quote_plus('rodrigo-559-UE') 
pasword= quote_plus('contraseña392') 

mongoURL= 'mongodb+srv://'+username +':'+pasword+'@datafinalnube.ielbwuw.mongodb.net/?retryWrites=true&w=majority'
client= pymongo.MongoClient(mongoURL, server_api=ServerApi('1'))

final_user=[]

class server(BaseHTTPRequestHandler):

    def save_age(self, url):
        if url.startswith('/'):
            url2=url[1:]
        else:
            url2=url
        print(url2)
        channel = ClarifaiChannel.get_grpc_channel()
        stub = service_pb2_grpc.V2Stub(channel)

        metadata = (('authorization', 'Key ' + "a3e0b6121bc8408b93b72ae3129afe36"),)

        userDataObject = resources_pb2.UserAppIDSet(user_id="rodrigorivasarevalo", app_id="Trabajo_final_app")

        post_model_outputs_response = stub.PostModelOutputs(
            service_pb2.PostModelOutputsRequest(
                user_app_id=userDataObject,
                model_id="age-demographics-recognition",
                inputs=[
                    resources_pb2.Input(
                        data=resources_pb2.Data(
                            image=resources_pb2.Image(
                                url=url2
                            )
                        )
                    )
                ]
            ),
            metadata=metadata
        )

        if post_model_outputs_response.status.code != status_code_pb2.SUCCESS:
            print(post_model_outputs_response.status)
            raise Exception("Post model outputs failed, status: " + post_model_outputs_response.status.description)

        # Since we have one input, one output will exist here.

        def chosen_age(output):
            for concept in output.data.concepts:
                x=concept.name
                return x

        output = post_model_outputs_response.outputs[0]
        return chosen_age(output)

        # Uncomment this line to print the full Response JSON
        #print(post_model_outputs_response)


    def save_user(self, path):
        final_user.append(path)

    def send(self, data, status, content_type):
        self.send_response(status)
        self.send_header("Content-Type", content_type)
        self.send_header("Content-Length", str(len(data)))
        self.end_headers()
        self.wfile.write(data)

    def save_header(self, header):
        b=header.split(" ")
        authHeader=b[1]
        base64decoded=base64.b64decode(authHeader)
        credentials=str(base64decoded.decode("utf-8")).split(":")
        print(credentials)
        credentials[1]=hashlib.sha256(credentials[1].encode('utf-8')).hexdigest()
        return credentials


    def do_POST(self): #registrar usuario
        status=200
        authHeader=self.headers.get('Authorization')
        credentials=self.save_header(authHeader)
        img=self.path
        age=self.save_age(img)

        json_entrada={'User':credentials[0], 'Pass':credentials[1], 'Age':age}
        result= client["Data"]["colection1"].find({'User':credentials[0]}) 
        for i in result:
            print(i)
            if i['User']==credentials[0]:
                status=403
        
        if status==200:
            if age=='0-2' or age=='3-9' or age=='10-19':
                status=403
                return self.send(('403').encode('utf-8'),status,'text/plain')
            else:
                self.save_user(credentials)
                client["Data"]["colection1"].insert_one(json_entrada)
                print(final_user)
                return self.send(('200').encode('utf-8'),status,'text/plain')

    def do_DELETE(self): #eliminar usuario
        status=200
        authHeader=self.headers.get('Authorization')
        credentials=self.save_header(authHeader)
        json_entrada={"User":credentials[0], "Pass":credentials[1]}
        result= client["Data"]["colection1"].find(json_entrada)
        for p in result:
            if p['User']==credentials[0]:
                print('usuario bien')
                if p['Pass']==credentials[1]:
                    print('contraseña bien')
                    client["Data"]["colection1"].delete_many(json_entrada)
                    return self.send(('bien').encode('utf-8'),status,'text/plain')
        status=403    
        return self.send(('error').encode('utf-8'),status,'text/plain')



    def do_PUT(self): #cambio de contraseña
        status=200
        authHeader=self.headers.get('Authorization')
        new_pass=self.path.replace('/users/update/', '')
        new_pass_img=new_pass.split('/',1)
        new_pass_img[0]=hashlib.sha256(new_pass_img[0].encode('utf-8')).hexdigest()
        
        credentials=self.save_header(authHeader)
        result= client["Data"]["colection1"].find({'User':credentials[0], 'Pass':credentials[1]})
        for p in result:
            if p['User']==credentials[0]:
                if p['Pass']==credentials[1]:
                    client["Data"]["colection1"].update_one({'User':credentials[0]},{'$set':{'Age':self.save_age(new_pass_img[1])}})
                    client["Data"]["colection1"].update_one({'User':credentials[0]},{'$set':{'Pass':new_pass_img[0]}})
                    return self.send(('Bien').encode("utf-8"),status,'text/plain')
        status=403
        return self.send(('mal').encode("utf-8"),status,'text/plain')

    def do_GET(self): #comprobar los credenciales y edad
        status=200
        status=200
        authHeader=self.headers.get('Authorization')
        credentials=self.save_header(authHeader)
        json_entrada={"User":credentials[0], "Pass":credentials[1]}
        result= client["Data"]["colection1"].find(json_entrada)
        for p in result:
            if p['User']==credentials[0]:
                if p['Pass']==credentials[1]:
                    #if p['age']=='20-29':   Ya dependiendo de los requerimientos del usuario se pueden poner diversas condiciones, por ejemplo con esta solo podrian acceder los que esten entre 20 y 29 años
                    return self.send(('200').encode("utf-8"),status,'text/plain')

        status=403
        return self.send(('403').encode("utf-8"),status,'text/plain')


if __name__ == "__main__":
    PORT = 8003
    httpd = HTTPServer(('localhost', PORT), server)
    print("Starting server on port %s" % PORT)


    try:
        httpd.serve_forever()
    except:
        print("Closing server...")