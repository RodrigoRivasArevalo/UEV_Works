import base64 
from distutils.debug import DEBUG
from http.server import HTTPServer, BaseHTTPRequestHandler
import ssl
import json
import requests
from requests.auth import HTTPBasicAuth
import hashlib

def createUser(header,img):
    r=requests.post(url='http://localhost:8003/'+img, headers= {"Authorization": str(header)})
    return r.status_code

def updateUser(header,new_img):
    r=requests.put(url='http://localhost:8003/'+new_img, headers= {"Authorization": str(header)})
    return r.status_code

def autenticateUser(header):
    r=requests.get(url='http://localhost:8003/', headers= {"Authorization": str(header)})
    return r.status_code

def deleteUser(header):
    r=requests.delete(url='http://localhost:8003/', headers= {"Authorization": str(header)})
    return r.status_code


