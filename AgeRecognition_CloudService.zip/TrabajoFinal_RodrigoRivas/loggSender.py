import requests
import json
from http.server import HTTPServer, BaseHTTPRequestHandler
import ssl



def sendLogg(ID, origin, lvl, mensaje):
    body={'ID': ID,'origin':origin,'lvl': lvl,'mensaje':mensaje}
    bodyJSON=json.dumps(body).encode('utf-8')
    r=requests.post('http://localhost:8002',data=bodyJSON)
    

