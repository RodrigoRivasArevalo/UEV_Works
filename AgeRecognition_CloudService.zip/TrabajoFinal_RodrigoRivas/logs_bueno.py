from distutils.debug import DEBUG
from http.server import HTTPServer, BaseHTTPRequestHandler
import json
import logging
import ssl
import uuid

class server(BaseHTTPRequestHandler):

    def send(self, data, status, content_type):
        self.send_response(status)
        self.send_header("Content-Type", content_type)
        self.send_header("Content-Length", str(len(data)))
        self.end_headers()
        self.wfile.write(data)

    def do_POST(self):
        contentLen=self.headers.get('Content-Length')
        if contentLen:
            body=self.rfile.read(int(contentLen))
        try:
            request=json.loads(body)
            print(request)
            logging.log(request['lvl'], body)

            return self.send(''.encode('utf-8'),200,'text/plain')

        except:
            status=400
            response={}
            response['Error']='Invalid JSON'
            self.send((json.dumps(response).encode('utf-8')),status,'application/json')


if __name__ == "__main__":
    FORMAT = '%(asctime)s - %(levelname)s: %(funcName)s: %(message)s'
    logging.basicConfig(format=FORMAT,filename='example.log', level='DEBUG')
    PORT = 8002
    httpd = HTTPServer(('localhost', PORT), server)
    print("Starting server on port %s" % PORT)
    

    try:
        httpd.serve_forever()
    except:
        print("Closing server...")
