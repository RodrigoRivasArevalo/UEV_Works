from distutils.debug import DEBUG
from http.server import HTTPServer, BaseHTTPRequestHandler
import urllib.parse
import json
from datetime import datetime
import logging
import ssl
import uuid
import loggSender
import authSender

final_path=[]
final_time=[]
final_final={}

#notese que el programa solo funcionara cuando lo ejecute yo, ya que no tengo puesto en mongoDB que pueda recibir peticiones de todas las IP (esto tambien pasara en el  boletin4)

class server(BaseHTTPRequestHandler):

    def save_path(self, path):
        now = datetime.now()
        current_time=now.strftime('%H:%M:%S')
        final_path.append(path)
        final_time.append(current_time)
        final_final['Path']=final_path
        final_final['Time']=final_time
        
        return print(final_final)
    

    def send(self, data, status, content_type):
        self.send_response(status)
        self.send_header("Content-Type", content_type)
        self.send_header("Content-Length", str(len(data)))
        self.end_headers()
        self.wfile.write(data)

  
    def do_GET(self): #imprimir dependiendo de la edad
        #se podrian ppner diferentes enpoints para las comprobaciones, eso depende ya de las necesidades del cliente
        ID=uuid.uuid4()
        loggSender.sendLogg(str(ID),'get','INFO','Comenzando metodo get')
        aut=self.headers.get('Authorization')
        auten=authSender.autenticateUser(aut)

        if auten==200:
            status=200
            ID=uuid.uuid4()
            loggSender.sendLogg(str(ID),'get','INFO','Todo ocurrio correctamente')
            return self.send(('El usuario tiene permisos').encode("utf-8"),status,'application/json')
                
        else:
            status=403
            ID=uuid.uuid4()
            loggSender.sendLogg(str(ID),'post','WARNING','Credenciales incorrectos')
            return self.send(('Por favor inicie sesion correctamente').encode("utf-8"),status,'text/plain')
                

    def do_POST(self): #creacion de usuario
        ID=uuid.uuid4()
        loggSender.sendLogg(str(ID),'post','INFO','Comenzando metodo post')
        status=200
        path=self.path
        
        if path.startswith('/users/create'):
            aut=self.headers.get('Authorization')
            img=self.path.replace("/users/create/","")
            auten=authSender.createUser(aut,img)
            if auten==403:
                ID=uuid.uuid4()
                loggSender.sendLogg(str(ID),'post','WARNING','El usuario no esta autorizado')
                return self.send((('ocurrio un problema con la creacion del usuario, intentelo de nuevo').encode("utf-8")),status,'text/plain')                
            else:
                ID=uuid.uuid4()
                loggSender.sendLogg(str(ID),'post','INFO','Metodo post con endpoint create realizado con exito')
                return self.send((('Usuario creado con exito').encode("utf-8")),status,'text/plain')
            
        else:
            aut=self.headers.get('Authorization')
            auten=authSender.autenticateUser(aut)
            if auten==200:
                ID=uuid.uuid4()
                loggSender.sendLogg(str(ID),'post','INFO','Credenciales Correctos')
                return self.send(('Autorizado').encode("utf-8"),status,'text/plain')
            else:
                status=403
                ID=uuid.uuid4()
                loggSender.sendLogg(str(ID),'post','WARNING','Credenciales incorrectos')
                return self.send(('No Autorizado').encode("utf-8"),status,'text/plain')



    def do_PUT(self): #actualiza 
        ID=uuid.uuid4()
        loggSender.sendLogg(str(ID),'put','INFO','Comenzando metodo put')
        status=200
        mensaje={}
        mensaje['Exito']='Datos cambiados con exito'
        path_entrante=self.path
        new_pass=path_entrante

        if path_entrante.startswith('/users/update'):
            aut=self.headers.get('Authorization')
            auten=authSender.updateUser(aut,new_pass)
            if auten==403:
                ID=uuid.uuid4()
                loggSender.sendLogg(str(ID),'put','WARNING','credenciales incorrectos')
                return self.send((('ocurrio un problema con la la actualizacion de los credenciales, intentelo de nuevo').encode("utf-8")),status,'text/plain')                
            else: 
                ID=uuid.uuid4()
                loggSender.sendLogg(str(ID),'put','INFO','Metodo put con endpoint update realizado con exito')
                return self.send((('credenciales actualizadas con exito').encode("utf-8")),status,'text/plain')

        else:
            ID=uuid.uuid4()
            loggSender.sendLogg(str(ID),'put','WARNING','El endpoint no existe')
            status=404
            return self.send((('Use un path con endpoint correcto').encode("utf-8")),status,'text/plain')
        

    def do_DELETE(self): #borra
        ID=uuid.uuid4()
        loggSender.sendLogg(str(ID),'delete','INFO','Comenzando metodo delete')
        status=200
        path_entrante=self.path
        aut=self.headers.get('Authorization')

        if path_entrante.startswith('/users/delete'):
            auten=authSender.deleteUser(aut)
            if auten==403:
                ID=uuid.uuid4()
                loggSender.sendLogg(str(ID),'put','WARNING','credenciales incorrectos')
                return self.send((('ocurrio un problema con la eliminacion del perfil, intentelo de nuevo').encode("utf-8")),status,'text/plain')                
            else:
                ID=uuid.uuid4()
                loggSender.sendLogg(str(ID),'put','INFO','Metodo put con endpoint update realizado con exito')
                return self.send((('Usuario borrado con exito').encode("utf-8")),status,'text/plain')
        else:
            ID=uuid.uuid4()
            loggSender.sendLogg(str(ID),'put','WARNING','El endpoint no existe')
            status=404
            return self.send((('Use un path con endpoint correcto').encode("utf-8")),status,'text/plain')


if __name__ == "__main__":
    PORT = 8001
    httpd = HTTPServer(('localhost', PORT), server)
    print("Starting server on port %s" % PORT)
    
    sslContext= ssl.create_default_context(ssl.Purpose.CLIENT_AUTH)
    sslContext.load_cert_chain(certfile="test.cert",keyfile="test.key")
    httpd.socket=sslContext.wrap_socket(sock=httpd.socket,server_side=True)

    try:
        httpd.serve_forever()
    except:
        print("Closing server...")
